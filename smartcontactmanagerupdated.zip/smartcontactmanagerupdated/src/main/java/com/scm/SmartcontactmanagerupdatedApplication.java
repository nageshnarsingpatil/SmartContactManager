package com.scm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@EnableAutoConfiguration(exclude = OAuth2ClientAutoConfiguration.class)
public class SmartcontactmanagerupdatedApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartcontactmanagerupdatedApplication.class, args);
	}
//00bff0cc-c9b6-4d42-a6f5-49720b0d7c45
}
