package com.scm.helper;

public enum messageType {

	blue,red,green,yellow
}
