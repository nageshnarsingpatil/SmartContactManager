package com.scm.helper;

public class AppConstants {

	
	public static final String APP_NAME="SCM";
	public static final String Role_USER="ROLE_USER";
}
